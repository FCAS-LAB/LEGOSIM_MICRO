#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/time.h>
#include <cassert>
#include <cstdio>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <string>

#include "apis_c.h"
#include "../../interchiplet/includes/pipe_comm.h"

InterChiplet::PipeComm global_pipe_comm;
/**
 * 矩阵乘法的核心函数，由每个线程都会运行一次本函数，
 * 根据线程编号不同计算出位于结果矩阵不同位置的数据。
 */

void matrix_mul(int* M, int* N, int* P, int Row, int Col, int id) {
    for (int i = 0; i < Row; i++) {
        for (int j = 0; j < Col; j++) {
            int sum = 0;
            for (int k = 0; k < Col/3; k++) {
                int a = M[i * Col + id * Col/3 + k];
                int b = N[id * Col * Row/3 + j + k * Col];
                sum += a * b;
            }
            P[i*Col+j] = sum;
        }
    }
}

int main(int argc, char** argv) {
    // 读取本进程所代表的chiplet编号

    int idX = atoi(argv[1]);
    int idY = atoi(argv[2]);

    int Row = 6;
    int Col = 6;

    int *A = (int *)malloc(sizeof(int) * Row * Col);
    int *B = (int *)malloc(sizeof(int) * Row * Col);
    int *C = (int *)malloc(sizeof(int) * Row * Col);

    memset(C, 0, sizeof(int) * Row * Col);

    long long unsigned int timeNow = 1;
    std::string fileName = InterChiplet::receiveSync(2, 2, idX, idY);
    global_pipe_comm.read_data(fileName.c_str(), A, sizeof(int) * Row * Col);
    long long int time_end = InterChiplet::readSync(timeNow, 2, 2, idX, idY, sizeof(int) * Row * Col, 0);

    for (int i = 0; i < Row * Col; i++) {
        if (0 == i%Row) {
            printf("\n");
        }
        printf("%d  ", A[i]);
    }
    printf("\n");

    fileName = InterChiplet::receiveSync(2, 2, idX, idY);
    global_pipe_comm.read_data(fileName.c_str(), B, sizeof(int) * Row * Col);
    time_end = InterChiplet::readSync(time_end, 2, 2, idX, idY, sizeof(int) * Row * Col, 0);

    for (int i = 0; i < Row * Col; i++) {
        if (0 == i%Row) {
            printf("\n");
        }
        printf("%d  ", A[i]);
    }
    printf("\n");

    uint32_t frequency = 10;
    uint8_t ddr_row = 3;
    uint8_t ddr_column = 3;
    int random = rand();
    int data_size = (random % ddr_row*ddr_column) / (8 * frequency * sizeof(int8_t));
    int8_t *ddr_data = (int8_t*)malloc((data_size+1) * sizeof(int8_t));
    InterChiplet::launchSync(idX, idY, 2, 0);
    time_end = InterChiplet::writeSync(time_end, idX, idY, 2, 0, 1, InterChiplet::SPD_LAUNCH);

    fileName = InterChiplet::sendSync(idX, idY, 2, 0);
    global_pipe_comm.write_data(fileName.c_str(), &random, sizeof(int));
    time_end = InterChiplet::writeSync(time_end, idX, idY, 2, 0, sizeof(int), 0);

    fileName = InterChiplet::receiveSync(2, 0, idX, idY);
    global_pipe_comm.read_data(fileName.c_str(), ddr_data, (data_size+1) * sizeof(int8_t));
    time_end = InterChiplet::readSync(time_end, 2, 0, idX, idY, (data_size+1) * sizeof(int8_t), 0);

    int id = 2*idX + idY;
    // calculate
    matrix_mul(A, B, C, Row, Col, id);

    for (int i = 0; i < Row * Col; i++) {
        if (0 == i%Row) {
            printf("\n");
        }
        printf("%d  ", C[i]);
    }
    printf("\n");

    fileName = InterChiplet::sendSync(idX, idY, 2, 2);
    global_pipe_comm.write_data(fileName.c_str(), C, sizeof(int) * Row * Col);

    InterChiplet::writeSync(time_end, idX, idY, 2, 2, sizeof(int) * Row * Col, 0);
    
    free(A);
    free(B);
    free(C);
    return 0;
}
